self.assetsManifest = {
  "version": "Tq5i9IfN",
  "assets": [
    {
      "hash": "sha256-1dlLfKlX5dGAWW49GAv91c5w/rB5E3a1UCwVaoY9WXo=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.bcb3imylv4.wasm"
    },
    {
      "hash": "sha256-ypXhsQ0jty6FNmJF3oYg520qS0DUMYSw4AMAlkQOMwM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.emt5hhf3l8.wasm"
    },
    {
      "hash": "sha256-O7BF+rEoiVhW842kcX8892CIZch4n+M4j093gYPK3DQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.b038f00maf.wasm"
    },
    {
      "hash": "sha256-GjI9vkQKnVxmTLe8o7kZYAwFxKE0/UQnSKrzxuXGAsQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.u3l5g6tuv0.wasm"
    },
    {
      "hash": "sha256-FQjLsQaz4KTpgQKQkcTn5A5IuUgcYT6MpYuBsN/vjX0=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.7d9a22amlg.wasm"
    },
    {
      "hash": "sha256-kizMyczNs6pFkLVfw3WQsZxAo/8HgmtiDuHyKMQLmpA=",
      "url": "_framework/Microsoft.Extensions.Configuration.iclqaprdn6.wasm"
    },
    {
      "hash": "sha256-hQEwzy0TybMCm3gB0uuwX/76hGXeMoeQpYkdqoT3EoQ=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p7r7ot5a93.wasm"
    },
    {
      "hash": "sha256-MOVlPkeO9+8Nu3CBHZqiF9YgpspbjBuCIS4K9LqliPs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.clr2lmubvg.wasm"
    },
    {
      "hash": "sha256-vWPk+q24R7G5r4Er4ffcvPEpySn58oMZAInTCvICZQw=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.njwqhpkmcq.wasm"
    },
    {
      "hash": "sha256-0PwVT3DJI3W4JqGJbzbuXm7Z6pEsGxwIJp8zWaidzJw=",
      "url": "_framework/Microsoft.Extensions.Logging.g06jewh4ge.wasm"
    },
    {
      "hash": "sha256-MQw+btuIjeEORE1gAryF38E3u9trx2G+EV0BlehmnyE=",
      "url": "_framework/Microsoft.Extensions.Options.hsbmfqd5yr.wasm"
    },
    {
      "hash": "sha256-UowUSFSAfDomzYKWFBBhqaGAuvQ+sz8UWs4W5L4y3jQ=",
      "url": "_framework/Microsoft.Extensions.Primitives.qq9k2j3qlh.wasm"
    },
    {
      "hash": "sha256-WuuQXW1+AnPHafZKt7ukqmwRDrGYbEV2LhxNuPl+ybo=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.y1ydbrr1bj.wasm"
    },
    {
      "hash": "sha256-o1A7RYF+OAkzNWIEGltWoVZA4DnL7CYcYRsVZmZz9SE=",
      "url": "_framework/Microsoft.JSInterop.vllxxpyqll.wasm"
    },
    {
      "hash": "sha256-Q4gFHcz3mn9qovXQogTW0C5QR35m5DXaq0Em7I39/vI=",
      "url": "_framework/NightReignTimer.7bjer5k718.wasm"
    },
    {
      "hash": "sha256-kXfPmJ6+TbQAP0UxmlBgT5ZlcP4SXorTEqTiozxW+18=",
      "url": "_framework/System.Collections.Concurrent.dpcpjq5awi.wasm"
    },
    {
      "hash": "sha256-i+DxbIWVv8PjrVUuy6SdxGBhmy90ieSrlG21KC61fk0=",
      "url": "_framework/System.Collections.Immutable.tmw1g9f0td.wasm"
    },
    {
      "hash": "sha256-crD2DP8dTb9gOby3Wxa1BrSOXz03qKOZWI0WuMnkz9c=",
      "url": "_framework/System.Collections.exwvgq8nho.wasm"
    },
    {
      "hash": "sha256-N3oqk+07pwp3PuQa+kS3PGurE5Cb0CphN2CSc2jaW5Q=",
      "url": "_framework/System.ComponentModel.Primitives.j5ngxcb2zb.wasm"
    },
    {
      "hash": "sha256-id0kUaVPNVzg6GkVc6pW3d00DuM1F9zPip6Yoyd1DIs=",
      "url": "_framework/System.ComponentModel.TypeConverter.zd06rsrlf6.wasm"
    },
    {
      "hash": "sha256-WyPLE0inD0/vY79fvGY+k+jDku6WEB8WJruWIMhiBXM=",
      "url": "_framework/System.ComponentModel.hd4i21d5zf.wasm"
    },
    {
      "hash": "sha256-ikqTNMM4nCzTvy0vq+eyrfJQJQsIKdPkd6r2Wj+W9CI=",
      "url": "_framework/System.Console.e26jkbjtyb.wasm"
    },
    {
      "hash": "sha256-d4Fv2UP7j+pqOrhljw06Xjdf1UB0VVgcWQAZYM+e2Ak=",
      "url": "_framework/System.IO.Pipelines.3p3f5vckx6.wasm"
    },
    {
      "hash": "sha256-lV2rLKp5/JNk1gpThEpuyCHlzSBnrZsM/L4fnN9Mj0M=",
      "url": "_framework/System.Linq.5kwvrzgh9k.wasm"
    },
    {
      "hash": "sha256-T4V4WK4ivondTGxxmpFrh6FtW5g8YISuktRz5K9Bp1E=",
      "url": "_framework/System.Memory.ddx3v4m9gx.wasm"
    },
    {
      "hash": "sha256-4QI1wOCtQSq/83+bNlWTBmCg1wggLcCDsXLIzGRPAJA=",
      "url": "_framework/System.Net.Http.jvborohthi.wasm"
    },
    {
      "hash": "sha256-KH4CVAPEDPjgX5PXvYBbhlTzNNL/Own3ELMwYvJ+tzM=",
      "url": "_framework/System.Net.Primitives.kdvc0a7ikr.wasm"
    },
    {
      "hash": "sha256-5c1U4CNNrpvP/GiP0JMUsKzUy+nTJxL/oavjEMANvQA=",
      "url": "_framework/System.ObjectModel.fjm8uc0elu.wasm"
    },
    {
      "hash": "sha256-Deq/N4+kVFomtW+AtFjLyHQ7B2N9R1UHSYDyWBTJ93Y=",
      "url": "_framework/System.Private.CoreLib.1vr4cqpzd3.wasm"
    },
    {
      "hash": "sha256-3YefOmWC2eidgkKSeVGau5E6HH5qFZpz26UDn75oBAw=",
      "url": "_framework/System.Private.Uri.jwtff51u5g.wasm"
    },
    {
      "hash": "sha256-pLr/Ys4hCRUIbnJOTabUttdOQTgaKzJPRmT6/do1uGg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.83zwdhfd7p.wasm"
    },
    {
      "hash": "sha256-VoMuQQOfMpqpM8kBlij40mh7vhtfMLMuUCF7CoyF0NA=",
      "url": "_framework/System.Runtime.qkkupkfxyv.wasm"
    },
    {
      "hash": "sha256-9FZLttu5iPwF9M7jckzJNogrhKhsHb9VlRtzW9+OH44=",
      "url": "_framework/System.Text.Encodings.Web.suy6578t21.wasm"
    },
    {
      "hash": "sha256-sXuIXXV6GDrgOHS7hgPVUT0qP7QuwAvYcUwGzYyxrY0=",
      "url": "_framework/System.Text.Json.jjhatov2mh.wasm"
    },
    {
      "hash": "sha256-dAw+dIKra7ljgRE+eVWL5wTVKKXPJi7x/AdHfLLcFDs=",
      "url": "_framework/System.Text.RegularExpressions.k0eu65ve7y.wasm"
    },
    {
      "hash": "sha256-ViNRvhyxlTugIlqJHamw/HwbXlg/YWcrANmxuTM0tfg=",
      "url": "_framework/System.ezrw3d5kw2.wasm"
    },
    {
      "hash": "sha256-5wPjO75dyqNWTTgwW5eDzNYSvIrfTW3LpEZUF945eFY=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HHqsNtcX76Ik012KVAobmCLooIZ2znhTFCqfijzEdi0=",
      "url": "_framework/dotnet.native.swgexbmoy7.wasm"
    },
    {
      "hash": "sha256-/ifJokfQvXKw1hEziCkYR9SOJIKSdGG/UKw5gbLWrj0=",
      "url": "_framework/dotnet.native.uhsveqo9bs.js"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-Xj4HYxZBQ7qqHKBwa2EAugRS+RHWzpcTtI49vgezUSU=",
      "url": "bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-YXh8lAu17RhUcqY3VRWtYMkxgpfwL0+PLG9ROuFbSSI=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-KdsMYhJZ5IHJx8Ew1Gr/Q9qh9c852SVMrluyb/VFJ4U=",
      "url": "index.html"
    },
    {
      "hash": "sha256-58gkTo5R2q1L9QvE7J2RVM/6xTUloRweUN6DrUd0I1g=",
      "url": "manifest.webmanifest"
    }
  ]
};
